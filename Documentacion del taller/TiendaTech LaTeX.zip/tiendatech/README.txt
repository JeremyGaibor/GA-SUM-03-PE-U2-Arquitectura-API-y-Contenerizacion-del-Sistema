TiendaTech — Documento IEEE en LaTeX
=====================================

Contenido:
  main.tex      -> documento principal (formato IEEE, clase IEEEtran), en espanol.
  img/          -> las 8 figuras + el arbol de archivos (Anexo D).

COMO COMPILAR
-------------
Opcion 1 (recomendada) — Overleaf:
  1. Crear proyecto en blanco y subir main.tex y la carpeta img/.
  2. Menu -> Compiler: pdfLaTeX. Compilar.
  (Overleaf ya incluye la clase IEEEtran y babel-spanish.)

Opcion 2 — Local (TeX Live / MiKTeX completo):
  pdflatex main.tex
  pdflatex main.tex      (segunda pasada para refs y citas)

  Si falta la clase IEEEtran o el idioma:
    TeX Live : sudo tlmgr install ieeetran babel-spanish
    MiKTeX   : se instalan en automatico al compilar.

Motor: pdfLaTeX. Se ejecuta dos veces para resolver \ref y \cite.
