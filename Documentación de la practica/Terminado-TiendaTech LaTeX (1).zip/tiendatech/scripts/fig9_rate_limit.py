#!/usr/bin/env python3
"""
Esquema del comportamiento esperado del control de tasa de Nginx
(limit_req zone rate=100r/m burst=20 nodelay) ante una rafaga de
130 solicitudes desde una unica IP en menos de 60 s.

NO representa datos medidos, sino el comportamiento definido por la
configuracion: se admite la rafaga inicial (burst) y el resto se
rechaza con 429. La evidencia empirica se obtiene ejecutando el
protocolo de la Seccion de Materiales y Metodos (bucle de 130
solicitudes) y capturando las respuestas en Postman/terminal.

Ejecutar:  python3 fig9_rate_limit.py  ->  ../img/fig9_rate_limit.png
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

n = 130
admitidas = 21          # 1 + burst(20) admitidas de inmediato (nodelay)
idx = np.arange(1, n + 1)
estado = np.where(idx <= admitidas, 1, 0)   # 1 = 200 OK, 0 = 429
colores = np.where(estado == 1, "#2f855a", "#c53030")

fig, ax = plt.subplots(figsize=(7.2, 3.2))
ax.bar(idx, np.ones(n), color=colores, width=1.0)
ax.axvline(admitidas + 0.5, color="black", linestyle="--", linewidth=1)
ax.text(admitidas + 3, 0.5,
        "umbral burst\n(429 a partir de aqui)",
        fontsize=8, va="center")
ax.set_xlabel("Solicitud en la rafaga (orden de llegada)")
ax.set_yticks([])
ax.set_xlim(0.5, n + 0.5)
ax.set_title("Esquema esperado del control de tasa "
             "(rate=100r/m, burst=20, nodelay)")
ax.legend(handles=[Patch(color="#2f855a", label="200 OK (admitida)"),
                   Patch(color="#c53030", label="429 Too Many Requests")],
          loc="upper right", fontsize=8)
fig.tight_layout()
fig.savefig("../img/fig9_rate_limit.png", dpi=150)
print("Figura generada: ../img/fig9_rate_limit.png")
