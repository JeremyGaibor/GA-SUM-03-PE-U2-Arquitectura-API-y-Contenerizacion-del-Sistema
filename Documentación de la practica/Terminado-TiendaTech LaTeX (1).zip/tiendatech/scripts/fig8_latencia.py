#!/usr/bin/env python3
"""
Reproduce la Figura 8 del informe TiendaTech:
latencia por endpoint (media, mediana y P95, n=5).

Los valores provienen de la Tabla VI (estadistica descriptiva),
calculada a partir de las 5 repeticiones registradas con Postman
(Tabla V). Ejecutar:  python3 fig8_latencia.py
Genera:  ../img/fig8_latencia.png
"""
import numpy as np
import matplotlib.pyplot as plt

endpoints = ["POST\n/auth/login", "POST\n/resources",
             "GET\n/notifications", "GET\n/resources"]
media   = [117.0, 80.0, 84.6, 202.8]
mediana = [ 98.0, 84.0, 35.0,  35.0]
p95     = [183.4, 92.0, 231.6, 701.0]

x = np.arange(len(endpoints))
w = 0.27
fig, ax = plt.subplots(figsize=(7.2, 4.0))
ax.bar(x - w, media,   w, label="Media",   color="#2b6cb0")
ax.bar(x,     mediana, w, label="Mediana", color="#90cdf4")
ax.bar(x + w, p95,     w, label="P95",     color="#1a365d")

for i in range(len(endpoints)):
    for off, val in zip((-w, 0, w), (media[i], mediana[i], p95[i])):
        ax.text(x[i] + off, val + 6, f"{val:.0f}",
                ha="center", va="bottom", fontsize=7)

ax.set_xlabel("Endpoint")
ax.set_ylabel("Latencia (ms)")
ax.set_title("Latencia por endpoint: media, mediana y P95 (n=5)")
ax.set_xticks(x)
ax.set_xticklabels(endpoints)
ax.legend()
ax.grid(axis="y", linestyle="--", alpha=0.4)
fig.tight_layout()
fig.savefig("../img/fig8_latencia.png", dpi=150)
print("Figura generada: ../img/fig8_latencia.png")
