TiendaTech — Documento IEEE en LaTeX (PFC Entrega 2)
=====================================================

CONTENIDO
  main.tex      -> documento principal (formato IEEE, clase IEEEtran), en espanol.
  img/          -> 9 figuras del informe:
                   fig1/fig2  diagramas C4 (nivel 2 y 3)
                   fig3       captura Portainer
                   fig4..fig7 capturas Postman
                   fig8       grafica de latencia (generada por script)
                   fig9       esquema del control de tasa (generado por script)
                   anexoD_arbol  estructura del proyecto
  scripts/      -> codigo reproducible de las graficas (matplotlib):
                   fig8_latencia.py     regenera img/fig8_latencia.png
                   fig9_rate_limit.py   regenera img/fig9_rate_limit.png

COMO COMPILAR
-------------
Opcion 1 (recomendada) — Overleaf:
  1. Crear proyecto en blanco y subir main.tex y las carpetas img/ y scripts/.
  2. Menu -> Compiler: pdfLaTeX. Compilar.
  (Overleaf ya incluye IEEEtran, babel-spanish, tikz y pgfplots.)

Opcion 2 — Local (TeX Live / MiKTeX completo):
  pdflatex main.tex
  pdflatex main.tex
  pdflatex main.tex   (3 pasadas: indice, lista de figuras/tablas, refs y citas)

  Si falta la clase IEEEtran o el idioma:
    TeX Live : sudo tlmgr install ieeetran babel-spanish pgfplots
    MiKTeX   : se instalan en automatico al compilar.

Motor: pdfLaTeX. Ejecutar 2-3 veces para resolver indice, listas, \ref y \cite.

REGENERAR LAS GRAFICAS (opcional)
---------------------------------
  cd scripts
  python3 fig8_latencia.py     # requiere: pip install matplotlib numpy
  python3 fig9_rate_limit.py

EVIDENCIA DE RATE LIMITING (429)  — IMPORTANTE
----------------------------------------------
La Fig. 9 es un ESQUEMA del comportamiento esperado. Para anadir la evidencia
empirica real de las respuestas 429:
  1. Levanta el stack: docker compose up --build
  2. Ejecuta el bucle de 130 solicitudes de la Seccion "Protocolo de prueba de
     saturacion" (PowerShell o curl) para superar el limite de 100 r/min.
  3. Captura la salida (Postman/terminal) mostrando los codigos 429.
  4. Guarda esa captura como img/fig9_rate_limit.png (mismo nombre) para que
     reemplace el esquema sin tocar el .tex; o anadela como figura adicional.
